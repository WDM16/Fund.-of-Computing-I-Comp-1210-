//********************************************************************
//  Searching.java       Author: Lewis/Loftus
//
//  Demonstrates the linear search and binary search algorithms.
//********************************************************************

public class SearchingStatic
{
//-----------------------------------------------------------------
//  Searches the specified array of objects for the target using
//  a linear search. Returns a reference to the target object from
//  the array if found, and null otherwise.
//-----------------------------------------------------------------
   public static <T extends Comparable<T>> T linearSearch (T[] list,
                                                            T target)
   {
      int index = 0;
      boolean found = false;
   
      while (!found && index < list.length)
      {
         if (list[index].equals(target))
            found = true;
         else
            index++;
      }
   
      if (found)
         return list[index];
      else
         return null;
   }

//-----------------------------------------------------------------
//  Searches the specified array of objects for the target using
//  a binary search. Assumes the array is already sorted in
//  ascending order when it is passed in. Returns a reference to
//  the target object from the array if found, and null otherwise.
//-----------------------------------------------------------------
   public static <T extends Comparable<T>> T binarySearch (T[] list,
                                                            T target)
   {
      int min=0, max=list.length-1, mid=(min+max)/2;
      boolean found = false;
   
      while (!found && min <= max)
      {
         if (list[mid].equals(target))
            found = true;
         else {
            if (target.compareTo(list[mid]) < 0)
               max = mid-1;
            else
               min = mid+1;
            mid = min + (max - min) / 2; // find center
         
         }
      }
   
      if (found)
         return list[mid];
      else
         return null;
   }
   
	
}
