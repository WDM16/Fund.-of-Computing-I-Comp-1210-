public interface TwoDShape {

   public int getNumberSides();
   
   public double getPerimeter();

}